<?php
declare(strict_types=1);

const CONTACT_TO_EMAIL = 'support@oncallsupport.co.nz';
const CONTACT_FROM_EMAIL = 'no-reply@oncallsupport.co.nz';

function respond(bool $ok, string $message, int $statusCode = 200): void
{
    http_response_code($statusCode);
    $isAjax = (
        (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
        (isset($_SERVER['HTTP_ACCEPT']) && str_contains((string) $_SERVER['HTTP_ACCEPT'], 'application/json'))
    );

    if ($isAjax) {
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'success' => $ok,
            'message' => $message,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $fallback = '/contact-us.html';
    $referer = isset($_SERVER['HTTP_REFERER']) ? (string) $_SERVER['HTTP_REFERER'] : '';
    $returnUrl = $referer !== '' ? $referer : $fallback;
    $separator = str_contains($returnUrl, '?') ? '&' : '?';
    $status = $ok ? 'success' : 'error';
    $encodedMessage = rawurlencode($message);

    header('Location: ' . $returnUrl . $separator . 'contact_status=' . $status . '&contact_message=' . $encodedMessage);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(false, 'Method not allowed.', 405);
}

// Honeypot field for basic bot filtering.
$website = trim((string) ($_POST['website'] ?? ''));
if ($website !== '') {
    respond(true, 'Thanks. Your request has been received.');
}

$name = trim((string) ($_POST['name'] ?? ''));
$email = trim((string) ($_POST['email'] ?? ''));
$phone = trim((string) ($_POST['phone'] ?? ''));

if ($name === '' || $email === '') {
    respond(false, 'Please provide your name and email.', 422);
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond(false, 'Please enter a valid email address.', 422);
}

$blacklistKeys = ['submit', 'g-recaptcha-response', 'website'];
$submittedFields = [];

foreach ($_POST as $key => $value) {
    $keyStr = trim((string) $key);
    if ($keyStr === '' || in_array($keyStr, $blacklistKeys, true)) {
        continue;
    }

    if (is_array($value)) {
        $flatValues = array_filter(array_map(static fn($v) => trim((string) $v), $value), static fn($v) => $v !== '');
        if ($flatValues === []) {
            continue;
        }
        $submittedFields[$keyStr] = implode(', ', $flatValues);
        continue;
    }

    $valueStr = trim((string) $value);
    if ($valueStr === '') {
        continue;
    }
    $submittedFields[$keyStr] = $valueStr;
}

$subject = 'New Website Contact Request - Oncall Websites';
$lines = [];
$lines[] = 'New contact form submission received.';
$lines[] = '';
$lines[] = 'Submitted At: ' . gmdate('Y-m-d H:i:s') . ' UTC';
$lines[] = 'IP Address: ' . ((string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
$lines[] = 'User Agent: ' . ((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'unknown'));
$lines[] = '';
$lines[] = 'Contact Details';
$lines[] = '--------------';
$lines[] = 'Name: ' . $name;
$lines[] = 'Email: ' . $email;
$lines[] = 'Phone: ' . ($phone !== '' ? $phone : 'Not provided');
$lines[] = '';
$lines[] = 'All Submitted Fields';
$lines[] = '--------------------';

foreach ($submittedFields as $field => $value) {
    $safeField = ucwords(str_replace(['_', '-'], ' ', $field));
    $lines[] = $safeField . ': ' . $value;
}

$body = implode(PHP_EOL, $lines) . PHP_EOL;

$safeName = preg_replace('/[\r\n]+/', ' ', $name) ?? 'Website Visitor';
$safeEmail = preg_replace('/[\r\n]+/', '', $email) ?? '';

$headers = [];
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-Type: text/plain; charset=UTF-8';
$headers[] = 'From: Oncall Websites <' . CONTACT_FROM_EMAIL . '>';
$headers[] = 'Reply-To: ' . $safeName . ' <' . $safeEmail . '>';
$headers[] = 'X-Mailer: PHP/' . phpversion();

$sent = @mail(CONTACT_TO_EMAIL, $subject, $body, implode("\r\n", $headers));

if (!$sent) {
    respond(false, 'We could not send your request right now. Please email support@oncallsupport.co.nz directly.', 500);
}

respond(true, 'Thanks! Your request has been submitted successfully.');
